package org.usfirst.frc.team5608.robot;



public class RobotMap {

	public static int leftStickPort = 0;
	public static int rightStickPort = 1;

	public static int leftDrivePort = 1;
	public static int rightDrivePort = 0;
	
	//public static int leftEncodePortA = 8;
	//public static int leftEncodePortB = 9;
	//public static int rightEncodePortA = 7;
	//public static int rightEncodePortB = 6;
	
	// Note that gyro can only be connected to analog port 0 or 1 due to need for
	// for hardware accumulator
	public static int gyroPort = 0;

/**
* Other constants and numbers
*/

	// Distance per pulse for drive encoders
	
	//public static double inchesPerPulse = 0.0291;
		
}

