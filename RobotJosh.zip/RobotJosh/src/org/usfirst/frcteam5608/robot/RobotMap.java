package org.usfirst.frcteam5608.robot;

public class RobotMap {

	public static int leftStickPort = 0;
	public static int rightStickPort = 1;

	public static int leftDrivePort = 1;
	public static int rightDrivePort = 0;
	
	public static int gyroPort = 0;
	
	
}
