package Hang;

import org.usfirst.frc.team5608.robot.*;

import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.command.Command;


/**This is the current code for the way that Josh wants the lift to work, It hasn't been approved by Mr. Ruggerio, however I made if anyways just in case since this is very
 *close to the original configuration of the Talos. */
public class Hanging extends Command {

	//Motor Initiations...
	private static SpeedController lift_motor1 = RobotMap.liftMotor1;
	private static SpeedController lift_motor2 = RobotMap.liftMotor2;
	private static SpeedController lift_motor3 = RobotMap.liftMotor3;
	
	//Solenoid Initiations...
	private static Solenoid sol1 = RobotMap.s1;
	private static Solenoid sol2 = RobotMap.s2;
	//private static Solenoid sol3 = RobotMap.s3;
	//private static Solenoid sol4 = RobotMap.s4;
	
	//Joystick Initiations...
	private static Joystick rightStick = RobotMap.rightStick;
	private static Joystick leftStick = RobotMap.leftStick;
	
	/**Method called in "execute" method to operate the lift.**/
	public void lift() {
		if(rightStick.getRawButton(3)) {
			lift_motor1.set(-.25);//moves lift down
			lift_motor2.set(-.25);
			lift_motor3.set(-.25);//moves lift down
			
		}else if(rightStick.getRawButton(10)) {//If button 3 on the joystick is down,
			lift_motor1.set(1);//the left motor makes the chain go upward.
			lift_motor2.set(1);//the right motor makes the chain go upward.
			lift_motor3.set(1);
		}
		else if(rightStick.getRawButton(2)) {//If button 3 on the joystick is not down and button 2 is down,
			lift_motor1.set(.25);//the left motor makes the chain go downward.
			lift_motor2.set(.25);//the right motor makes the chain go downward.
			lift_motor3.set(.25);
		}
		else {//If no buttons on the joystick are down,
			lift_motor1.set(0);//the left motor is set to 0
			lift_motor2.set(0);//and the right motor is set to 0.
			lift_motor3.set(0);}
		
	}
	public void air() {//left joystick
		if (leftStick.getRawButton(7)) {//If button 2 on the joystick is pressed,
			sol1.set(false);//arm1 is turned off.
		}
		else if(leftStick.getRawButton(6)) {//If button 2 on the joystick is not pressed and button 3 is pressed,
			sol1.set(true);//arm1 is turned on.
		}
		else if (leftStick.getRawButton(3)) {//If button 2 on the joystick is not pressed, button 3 is not pressed, and button 4 is pressed,
			sol2.set(true);//arm2 is turned on.
		}
		else if (leftStick.getRawButton(2)) {//If button 2 on the joystick is not pressed, button 3 is not pressed, button 4 is not pressed, and button 5 pressed,
			sol2.set(false);//arm2 is turned off.
		}
		
		
	/**This is the "method" called to operate the claw of the lift.*/
	/*public void claw() {
		if (rightStick.getRawButton(3)) {
			sol1.set(true);
			sol2.set(true);
			
		}else if (rightStick.getRawButton(2)) {
			sol1.set(false);
			sol2.set(false);
			
		}
		if (leftStick.getRawButton(3)) {
			sol3.set(true);
			sol4.set(true);
			
		}else if (leftStick.getRawButton(2)) {
			sol3.set(false);
			sol4.set(false);
			
		}*/
		
	}

	protected void initialize() {
		
	}

	protected void execute() {
		air();
		lift();
		
	}

	protected boolean isFinished() {
		return false;
	}

	protected void end() {
		
	}

	protected void interrupted() {
		
	}

}
