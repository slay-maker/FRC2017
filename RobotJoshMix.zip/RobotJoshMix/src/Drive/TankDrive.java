4package Drive;

import org.usfirst.frc.team5608.robot.RobotMap;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.command.Command;

public class TankDrive extends Command{

		
		//Motor Initiations...
		private static SpeedController rightMotor = RobotMap.right;
		private static SpeedController minirightMotor = RobotMap.miniright;
		private static SpeedController leftMotor = RobotMap.left;
		private static SpeedController minileftMotor = RobotMap.minileft;

		//Joystick Initiations...
		private static Joystick left_stick = RobotMap.leftStick;
		private static Joystick right_stick = RobotMap.rightStick;
		
		/**Method called to actually drive the robot.*/
		public void drive() {
			if (Math.abs(right_stick.getY()) > 0){
				rightMotor.set(-right_stick.getY()/2);
				minirightMotor.set(-right_stick.getY()/2);
				
			}else {
				rightMotor.set(0);
				
			}
			if (Math.abs(left_stick.getY()) > 0) {
				leftMotor.set(left_stick.getY()/2);
				minileftMotor.set(left_stick.getY()/2);
				
			}else {
				leftMotor.set(0);
				
			}
			
		}

		protected void initialize() {
			
		}

		protected void execute() {
			drive();
			
		}

		protected boolean isFinished() {
			return false;
			
		}

		protected void end() {
			
		}

		protected void interrupted() {
			
		}
	}