package Shoot;
import edu.wpi.first.wpilibj.*;

	import org.usfirst.frc.team5608.robot.*;

	import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.command.Command;


	/**This is the current code for the way that Josh wants the lift to work, It hasn't been approved by Mr. Ruggerio, however I made if anyways just in case since this is very
	 *close to the original configuration of the Talos. */
	public class Shooting extends Command {

		//Motor Initiations...
		//private static SpeedController lift_motor1 = RobotMap.liftMotor1;
		//private static SpeedController lift_motor2 = RobotMap.liftMotor2;
		
		//Solenoid Initiations...
		//private static Solenoid sol1 = RobotMap.s1;
		//private static Solenoid sol2 = RobotMap.s2;
		//private static Solenoid sol3 = RobotMap.s3;
		//private static Solenoid sol4 = RobotMap.s4;
		
		//Joystick Initiations...
		private static Joystick rightStick = RobotMap.rightStick;
		private static Joystick leftStick = RobotMap.leftStick;
		private static DigitalInput limitSwitch = RobotMap. limitSwitch;
		private static Relay grabber = RobotMap. grabber ;
		private static SpeedController shootMotorUpper = RobotMap.shootMotorupper;
		private static SpeedController shootMotorLower = RobotMap.shootMotorlower;
		
		
		/**Method called in "execute" method to operate the lift.**/
		public void shot() {
			if (rightStick.getRawButton(1)) {//If button 1 on the joystick is down,
				shootMotorUpper.set(-1);//the upper wheels move,
				shootMotorLower.set(1);//the lower wheels move,
				Timer.delay(.25);//and after 0.1 seconds,
				grabber.set(Relay.Value.kReverse);//the grabber starts moving to shoot the ball.
			}
				else if(limitSwitch.get()) {//If the limit switch is pressed,
				Timer.delay(.15);//after 0.25 seconds,
				grabber.set(Relay.Value.kOff);//the grabber stops moving.
			}
				else if(leftStick.getRawButton(1)) {//If the limit switch is not down and the right trigger is down,
				grabber.set(Relay.Value.kReverse);//the grabber moves.
			}
			
			//}
			else {//If button 1 on the joystick is down,
			grabber.set(Relay.Value.kOff);//the grabber stops moving,
				shootMotorUpper.set(0);//the upper wheels stop moving,
				shootMotorLower.set(0);//and the lower wheels stop moving.
			}
			
		}
		
		/**This is the "method" called to operate the claw of the lift.*/
		

		protected void initialize() {
			
		}

		protected void execute() {
			shot();
			
			
		}

		protected boolean isFinished() {
			return false;
		}

		protected void end() {
			
		}

		protected void interrupted() {
			
		}
}
