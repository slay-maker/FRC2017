package Auto;

import org.usfirst.frc.team5608.robot.RobotMap;

import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;

public class Autonomous extends Command 
{

	//Motor Initiations...
		private static SpeedController rightmotor = RobotMap.right;
		private static SpeedController minirightmotor = RobotMap.miniright;
		private static SpeedController leftmotor = RobotMap.left;
		private static SpeedController minileftmotor = RobotMap.minileft;
		private static SpeedController shootMotorupper = RobotMap.shootMotorupper;
		private static SpeedController shootMotorlower = RobotMap.shootMotorlower;
		//Misc Initiations...
		private static Timer time = new Timer();
		private static boolean timeCheck = false;
		public void initialize() {
			time.start();
			
		}
		
		public void execute() {
			initialize();
			
			//robot will go straight foward
			
				rightmotor.set(-.3);
				minirightmotor.set(-.3);
				leftmotor.set(.3);
				minileftmotor.set(.3);
				
				Timer.delay(4);
				//After 4 seconds robot will 
				
				//robot will turn
				
				rightmotor.set(-.3);
				minirightmotor.set(-.3);
				leftmotor.set(.3);
				minileftmotor.set(.3);
				
				Timer.delay(2);
				//After 2 seconds robot will
				
				rightmotor.set(-.3);
				minirightmotor.set(-.3);
				leftmotor.set(.3);
				minileftmotor.set(.3);
				
				Timer.delay(2);
				//After 2 seconds robot will
				
				rightmotor.set(-.3);
				minirightmotor.set(-.3);
				leftmotor.set(.3);
				minileftmotor.set(.3);
			
			

		
			timeCheck = true;{
			isFinished();}
			}
			
		
		
		protected boolean isFinished() {
			return timeCheck;
			
		}
		
		protected void end() {
			
		}
		
		protected void interrupted() {

		

		}
}
