package drive;


import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.GenericHID.Hand;
import edu.wpi.first.wpilibj.command.Command;

public class Howtomakejoystickdrive extends Command {
	
	//Joystick Initiations...
	public static Joystick leftStick = new Joystick(0);
    public static Joystick rightStick = new Joystick(1);
    
    //Motors Initiations....
    public static SpeedController right = new Talon(1);
	public static SpeedController left = new Talon(0);
    
	/**
	 * Method called for driving
	 */
    public void drive() {
    	
    	//Declaring the right analog stick to control the right motor
		if (Math.abs(rightStick.getY(Hand.kRight)) > 0) {
			right.set(rightStick.getRawAxis(5));
			
			
			
			
		}else {
			right.set(0);
			
			
		}
			
		//Declaring the left analog stick to control the left motors
		if (Math.abs(leftStick.getY(Hand.kLeft)) > 0) {
			left.set(-leftStick.getRawAxis(1));
			
		}else {
		left.set(0);
		}
			
		
		}
    
    protected void initialize() {
		
	}

    //Start the Command
	protected void execute() {
		drive();
		
	}

	protected boolean isFinished() {
		return false;
		
	}

	protected void end() {
		
	}

	protected void interrupted() {
		
	}

}
