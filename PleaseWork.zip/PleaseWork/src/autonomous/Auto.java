package autonomous;
import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

public class Auto
{
		public void go(Joystick leftJoystick, SpeedController leftWheels,SpeedController miniLeft,SpeedController rightWheels,SpeedController miniRight) {
		
//			if 	(SmartDashboard.getBoolean("DB/Button 0")){
			
				leftWheels.set(.65);//The left wheels are set to 0.2.
				miniLeft.set(.65);//                                                foward 
				rightWheels.set(-.65);//The right wheels are set to 0.2.
				miniRight.set(-.65);
		
				Timer.delay(4);//The robot remains in this state for 2 seconds.
				 leftWheels.set(0);//The left wheels are set to 0.
				 miniLeft.set(0);// stop after 2 sec.
				 rightWheels.set(0);//The right wheels are set to 0.
				 miniRight.set(0);
//		}
//		 else {
//				 leftWheels.set(.5);//The left wheels are set to 0.2.
//					miniLeft.set(.5);//                                                foward 
//				 rightWheels.set(-.5);//The right wheels are set to 0.2.
//				 miniRight.set(-.5);
//				
//				Timer.delay(1.2);//The robot remains in this state for 2 seconds.
//				 leftWheels.set(0);//The left wheels are set to 0.
//				 miniLeft.set(0);// stop after 2 sec.
//				 rightWheels.set(0);//The right wheels are set to 0.
//				 miniRight.set(0);
		 /*Timer.delay(.5);//The robot remains in this state for .5 seconds.
		 leftWheels.set(-1);//The left wheels are set to 1.
		 miniLeft.set(-1);
		rightWheels.set(1);//The right wheels are set to 1.
		 miniRight.set(1);
		
		 Timer.delay(5);//The robot remains in this state for 5 seconds.
		 leftWheels.set(0);//The left wheels are set to 0.
		 miniLeft.set(0);
		 rightWheels.set(0);//The right wheels are set to 0.
		 miniRight.set(0);
		
		Timer.delay(5);//The robot remains in this state for 5 seconds.
		 leftWheels.set(0);//The left wheels are set to 0.
		 miniLeft.set(0);
			rightWheels.set(0);//The right wheels are set to 0.
		 miniRight.set(0);*/
		
//		}
		
		}
}
