package autonomous;
//import edu.wpi.first.wpilibj.*;

public class AutonomousFun {

//	private RobotDrive myrobot;
//	private AnalogGyro gyro;
//	
//	double Kp = 0.03;
//	
//	public AutonomousFun(){
//		gyro = new AnalogGyro(1);
//		myrobot = new RobotDrive(1,2);
//		
//		
//		
//		myrobot.setExpiration(.1);
//	}
//	
//	public boolean autonomous() {
//		gyro.reset();
//		while (autonomous()){
//			double angle = gyro.getAngle();
//			myrobot.drive(-1.0, -angle*Kp);
//
//			Timer.delay(.004);
//		}
//		
//		myrobot.drive(.0, .0);
//		 return false;
//		}
}
