package shooting;
import edu.wpi.first.wpilibj.*;
public class stop {
	
	public void initialization(Joystick rightJoystick, SpeedController lowerWheels, SpeedController upperWheels){

		if (rightJoystick.getRawButton(7)){
			upperWheels.set(0);//the upper wheels stop moving,
			lowerWheels.set(0);
}
}
}