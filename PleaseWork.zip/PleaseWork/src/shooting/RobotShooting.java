package shooting;
import edu.wpi.first.wpilibj.*;
public class RobotShooting {
	public void shooting(Joystick rightJoystick, Relay grabber, SpeedController lowerWheels, SpeedController upperWheels) {
		if (rightJoystick.getRawButton(1)) {//If button 1 on the joystick is down,
			upperWheels.set(-1);//the upper wheels move,
			lowerWheels.set(1);//the lower wheels move,
			Timer.delay(.1);//and after 0.1 seconds,
			grabber.set(Relay.Value.kReverse);//the grabber starts moving to shoot the ball.
		}
		else {//If button 1 on the joystick is down,
			grabber.set(Relay.Value.kOff);//the grabber stops moving,
			upperWheels.set(0);//the upper wheels stop moving,
			lowerWheels.set(0);//and the lower wheels stop moving.
		}
	}
	public void grabbing(DigitalInput limitSwitch, Joystick leftJoystick, Relay grabber) {
		if(limitSwitch.get()) {//If the limit switch is pressed,
			Timer.delay(.25);//after 0.25 seconds,
			grabber.set(Relay.Value.kOff);//the grabber stops moving.
		}
		else if(leftJoystick.getRawButton(1)) {//If the limit switch is not down and the right trigger is down,
			grabber.set(Relay.Value.kReverse);//the grabber moves.
		}
	}
	
}