package hanging;
import edu.wpi.first.wpilibj.*;
public class RobotHanging {
	public void hanging(Joystick joystick, SpeedController leftLift, SpeedController rightLift, SpeedController middleLift) {
		if(joystick.getRawButton(3)){//right joystick
			leftLift.set(.5);//the left motor makes the chain go downward.
			rightLift.set(.5);//the right motor makes the chain go downward.
			middleLift.set(.5);
	}
		else if(joystick.getRawButton(10)) {//If button 3 on the joystick is down,
			leftLift.set(-1);//the left motor makes the chain go upward.
			rightLift.set(-1);//the right motor makes the chain go upward.
			middleLift.set(-1);
		}
		else if(joystick.getRawButton(2)) {//If button 3 on the joystick is not down and button 2 is down,
			leftLift.set(-.25);//the left motor makes the chain go downward.
			rightLift.set(-.25);//the right motor makes the chain go downward.
			middleLift.set(-.25);
		}
		else {//If no buttons on the joystick are down,
			leftLift.set(0);//the left motor is set to 0
			rightLift.set(0);//and the right motor is set to 0.
			middleLift.set(0);
			
		}	
	}
	public void air(Joystick joystick, Solenoid arm1, Solenoid arm2) {//left joystick
		if (joystick.getRawButton(7)) {//If button 2 on the joystick is pressed,
			arm1.set(false);//arm1 is turned off.
		}
		else if(joystick.getRawButton(6)) {//If button 2 on the joystick is not pressed and button 3 is pressed,
			arm1.set(true);//arm1 is turned on.
		}
		else if (joystick.getRawButton(3)) {//If button 2 on the joystick is not pressed, button 3 is not pressed, and button 4 is pressed,
			arm2.set(true);//arm2 is turned on.
		}
		else if (joystick.getRawButton(2)) {//If button 2 on the joystick is not pressed, button 3 is not pressed, button 4 is not pressed, and button 5 pressed,
			arm2.set(false);//arm2 is turned off.
		}
	}
}