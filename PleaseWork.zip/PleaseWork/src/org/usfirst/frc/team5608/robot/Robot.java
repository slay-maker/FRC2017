package org.usfirst.frc.team5608.robot;
import driving.*;
import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;
import hanging.*;

import org.usfirst.frc.team5608.robot.RobotMap;

import Defence.Chevel;
import shooting.*;
import autonomous.*;
public class Robot extends IterativeRobot {
	public static Compressor ok = RobotMap.mainok;
	public static DigitalInput limitSwitch = new DigitalInput(1);
	public static Joystick lLeftJoystick = new Joystick(0);
	public static Joystick lRightJoystick = new Joystick(1);
	public static Joystick rLeftJoystick = new Joystick(2);
	public static Joystick rRightJoystick = new Joystick(3);
	public static Joystick gamepad = new Joystick(4);
	//public static SpeedController grabber = new Joystick(9);
	public static Solenoid arm1 = new Solenoid(0);
	public static Solenoid arm2 = new Solenoid(1);
	public static SpeedController leftWheels = new Talon(0);
	public static SpeedController miniLeft = new Talon(1);
	public static SpeedController rightWheels = new Talon(2);
	public static SpeedController miniRight = new Talon(3);
	public static SpeedController lowerWheels = new Talon(4);
	public static SpeedController upperWheels = new Talon(5);
	public static SpeedController leftLift = new Talon(6); 
	public static SpeedController rightLift = new Talon(7);
	public static SpeedController middleLift = new Talon(8);
	//public static SpeedController medium_small = new Talon(9);
	public static SpeedController grabber = new Talon(9);
	
	
	
	RobotDriving drive = new RobotDriving();
	RobotShooting shoot = new RobotShooting();
	RobotHanging hang = new RobotHanging();
	Auto autonomousCommand = new Auto();
	JoshShooting josh= new JoshShooting();
	//Chevel chevel = new Chevel();
	stop Stop = new stop();
	CameraServer camera;
	//AutonomousFun fun = new AutonomousFun();
	
	public Robot() {
		camera = CameraServer.getInstance();
		camera.setQuality(50);
		camera.startAutomaticCapture("cam0");
		
	}
	
	public void robotInit() {
		
	}
	public void disabledInit() {
	}
	public void disabledPeriodic() {
		Scheduler.getInstance().run();
	}
	public void autonomousInit() {
		//Scheduler.getInstance().run();
		//autonomousCommand.go(lLeftJoystick, leftWheels, miniLeft, rightWheels, miniRight);
	}
	public void AutonomousPeriodic() {
		//Scheduler.getInstance().run();
		//autonomousCommand.go(leftWheels, miniLeft, rightWheels, miniRight);
		}
	public void teleopInit() {
	}
	public void teleopPeriodic() {
		Scheduler.getInstance().run();
		drive.driving(lLeftJoystick, lRightJoystick, leftWheels, rightWheels, miniLeft, miniRight, gamepad);
		josh.shooting(lRightJoystick, lLeftJoystick, limitSwitch, grabber, lowerWheels, upperWheels, gamepad);
		//shoot.shooting(lRightJoystick, grabber, lowerWheels, upperWheels);
		//shoot.grabbing(limitSwitch, lLeftJoystick, grabber);
		hang.hanging(lRightJoystick, leftLift, rightLift, middleLift);
		hang.air(lLeftJoystick, arm1, arm2);
		//chevel.up(lLeftJoystick, medium_small );
		Stop.initialization(lRightJoystick,lowerWheels, upperWheels);
		//chevel.down(lLeftJoystick, medium_small);
	}
	public void testPeriodic() {
		LiveWindow.run();
	}
}