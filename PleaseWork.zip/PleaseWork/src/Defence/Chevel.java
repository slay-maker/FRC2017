package Defence;

import edu.wpi.first.wpilibj.*;

public class Chevel {
	

	
	public void up (Joystick leftJoystick, SpeedController medium_small){

		if(leftJoystick.getRawButton(5)){//arm goes up
			
			medium_small.set(.5);//was .35
		   Timer.delay(1);
			medium_small.set(0);}
		else if (leftJoystick.getRawButton(4)){// arm goes down
		
			medium_small.set(-1);//was -.35
		 Timer.delay(1);
			medium_small.set(0);
}
		else  {
			medium_small.set(0);
		}
	}
	public void down (Joystick leftJoystick, SpeedController medium_small){	
		
		if(leftJoystick.getRawButton(4))// arm goes down
			
			medium_small.set(-1);
		//Timer.delay(1);
			//medium_small.set(0);
		else{
			medium_small.set(0);
       }
		
	//}

	}
}