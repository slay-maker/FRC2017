package autonomous;
import edu.wpi.first.wpilibj.*;

public class Auto
{
		public void go(SpeedController leftWheels,SpeedController miniLeft,SpeedController rightWheels,SpeedController miniRight) {
	
			
			leftWheels.set(.5);//The left wheels are set to 0.2.
			miniLeft.set(.5);//                                                foward 
		 rightWheels.set(-.5);//The right wheels are set to 0.2.
		 miniRight.set(-.5);
		
		Timer.delay(3);//The robot remains in this state for 2 seconds.
		 leftWheels.set(0);//The left wheels are set to 0.
		 miniLeft.set(0);// stop after 2 sec.
		 rightWheels.set(0);//The right wheels are set to 0.
		 miniRight.set(0);
		
		 /*Timer.delay(.5);//The robot remains in this state for .5 seconds.
		 leftWheels.set(-1);//The left wheels are set to 1.
		 miniLeft.set(-1);
		rightWheels.set(1);//The right wheels are set to 1.
		 miniRight.set(1);
		
		 Timer.delay(5);//The robot remains in this state for 5 seconds.
		 leftWheels.set(0);//The left wheels are set to 0.
		 miniLeft.set(0);
		 rightWheels.set(0);//The right wheels are set to 0.
		 miniRight.set(0);
		
		Timer.delay(5);//The robot remains in this state for 5 seconds.
		 leftWheels.set(0);//The left wheels are set to 0.
		 miniLeft.set(0);
			rightWheels.set(0);//The right wheels are set to 0.
		 miniRight.set(0);*/
		
		}
		

}
