package driving;
import edu.wpi.first.wpilibj.*;
public class RobotDriving {
	public void driving(Joystick leftJoystick, Joystick rightJoystick, SpeedController leftWheels, SpeedController rightWheels, SpeedController miniLeft, SpeedController miniRight) {
		if (Math.abs(leftJoystick.getY()) > 0) {//If the left joystick is tilted,
			leftWheels.set(-leftJoystick.getY());//the left wheels move at a speed relative to the joystick's tilt,
			miniLeft.set(-leftJoystick.getY()/2);//and the left mini wheels move at a speed relative to the joystick's tilt.
		}
		else {//If the left joystick is not tilted,
			leftWheels.set(0);//the left wheels stop moving,
			miniLeft.set(0);//and the left mini wheels stop moving.
		}
		if (Math.abs(rightJoystick.getY())  > 0) {//If the right joystick is tilted,
			rightWheels.set(rightJoystick.getY());//the right wheels move at a speed relative to the joystick's tilt,
			miniRight.set(rightJoystick.getY()/2);//and the right mini wheels move at a speed relative to the joystick's tilt.
		}
		else {//If the right joystick is not tilted,
			rightWheels.set(0);//the right wheels stop moving,
			miniRight.set(0);//and the right mini wheels move at a speed relative to the joystick's tilt.
		}
	}
}