package drive;

import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.GenericHID.Hand;
import edu.wpi.first.wpilibj.command.Command;

public class tShirtDriving extends Command {
	
	//Joystick Initiations...
	public static Joystick leftStick = new Joystick(1);
    public static Joystick rightStick = new Joystick(0);
    
    //Motors Initiations....=
    public static SpeedController right = new Talon(2);
    public static SpeedController miniright = new Talon(3);
	public static SpeedController left = new Talon(0);
	 public static SpeedController minileft = new Talon(1);
	 public static SpeedController upperWheels = new Talon(5);
	 public static SpeedController lowerWheels = new Talon(4);
	 public static SpeedController grabber = new Talon(9);
	 public static DigitalInput limitSwitch = new DigitalInput(1);
	 public static Solenoid Barrel1 = new Solenoid(3);
	 public static Solenoid Barrel2 = new Solenoid(1);
	 public static Solenoid Barrel3= new Solenoid(2);
	/**
	 * Method called for driving
	 */
    public void drive() {
    	
    	//Declaring the right analog stick to control the right motor
		if (Math.abs(rightStick.getY(Hand.kRight)) > 0) {
			right.set(rightStick.getRawAxis(5));
			miniright.set(rightStick.getRawAxis(5));
			
			
			
		}else {
			right.set(0);
			
			
		}
			
		//Declaring the left analog stick to control the left motors
		if (Math.abs(rightStick.getY(Hand.kLeft)) > 0) {
			left.set(-rightStick.getRawAxis(1));
			minileft.set(-rightStick.getRawAxis(1));
			
		}else {
		left.set(0);
		}
			
		
		}
    public void air(){
    	if (rightStick.getRawButton(3)) {//If button 2 on the joystick is pressed,
			Barrel1.set(true);
			Timer.delay(.25);
			Barrel1.set(false);
    	}
			else if (rightStick.getRawButton(4)) {//If button 2 on the joystick is pressed,
			Barrel2.set(true);
			Timer.delay(.25);
			Barrel2.set(false);
			}
			else if (rightStick.getRawButton(2)){ //If button 2 on the joystick is pressed,
				Barrel3.set(true);
				Timer.delay(.25);
				Barrel3.set(false);
			}
    	
			//else {	
					//Barrel1.set(false);
					//Barrel2.set(false);
					//Barrel3.set(false);
				//}
				}
    	//arm1 is turned off.
    public void comp(){
    	if (rightStick.getRawButton(1)) {//If button 2 on the joystick is pressed,
    		
    	}
 
    }
    public void shooting(){
    	
    	if (Math.abs(rightStick.getRawAxis(3)) > 0) {
			//left.set(rightStick.getRawAxis(3));
			
			upperWheels.set(-.5);//the upper wheels move,
			lowerWheels.set(.5);//the lower wheels move,
			Timer.delay(1);//and after 0.1 seconds,
			grabber.set(-1);//the grabber starts moving to shoot the ball.
		}
			else if(limitSwitch.get()) {//If the limit switch is pressed,
			Timer.delay(.15);//after 0.25 seconds,
			grabber.set(0);//the grabber stops moving.
		}
			else if (Math.abs(rightStick.getRawAxis(2)) > 0) {
				//right.set(-rightStick.getRawAxis(2));//If the limit switch is not down and the right trigger is down,
				grabber.set(-1);//the grabber moves.
		}
		
		//}
		else {//If button 1 on the joystick is down,
			grabber.set(0);//the grabber stops moving,
			upperWheels.set(0);//the upper wheels stop moving,
			lowerWheels.set(0);//and the lower wheels stop moving.
		}
    }
    protected void initialize() {
		
	}

    //Start the Command
	protected void execute() {
		drive();
		shooting();
		air();
		comp();
	}

	protected boolean isFinished() {
		return false;
		
	}

	protected void end() {
		
	}

	protected void interrupted() {
		
	}

}
