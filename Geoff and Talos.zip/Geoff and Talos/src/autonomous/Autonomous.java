package autonomous;

import org.usfirst.frc.team5608.robot.*;

import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.command.Command;

/**Code for autonomous. Should only move forward for 2 seconds. Currently under construction due to the whole "lost laptop" fiasco.*/
public class Autonomous extends Command 
{

	//Motor Initiations...
	private static SpeedController right_motor = PartsMap.right;
	private static SpeedController left_motor = PartsMap.left;
	
	//Misc Initiations...
	private static Timer time = new Timer();
	private static boolean timeCheck = false;
	public void initialize() {
		time.start();
		
	}
	
	public void execute() {
		initialize();
		
			right_motor.set(.3);
			left_motor.set(-.3);
			
			Timer.delay(4);
			right_motor.set(0);
			left_motor.set(0);
			
			right_motor.set(.5);
			left_motor.set(-.5);
			
			Timer.delay(2);
			right_motor.set(-.4);
			left_motor.set(-.15);
			
			Timer.delay(2);
			right_motor.set(0);
			left_motor.set(0);
		
		

	
		timeCheck = true;{
		isFinished();}
		}
		
	
	
	protected boolean isFinished() {
		return timeCheck;
		
	}
	
	protected void end() {
		
	}
	
	protected void interrupted() {

	

	}
	
}
