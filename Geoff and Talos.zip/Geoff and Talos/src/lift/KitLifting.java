package lift;

import org.usfirst.frc.team5608.robot.*;

import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.command.Command;

public class KitLifting extends Command{

	
	//Motor Initiations...
		private static SpeedController lift_motor = PartsMap.liftMotor1;
		
	//Solenoid Initiations...
		private static Solenoid sol1 = PartsMap.s1;
		private static Solenoid sol2 = PartsMap.s2;
		private static Solenoid sol3 = PartsMap.s3;
		
		//Joystick Initiations...
		private static Joystick logitech_stick = PartsMap.leftStick;
		
		
		
		/**This is the "method" called to operate the claw of the lift.*/
		public void claw() {
			
			
			if (logitech_stick.getRawButton(4))	{
				sol1.set(true);
				Timer.delay(.5);
				sol1.set(false);}
		
				
			if(logitech_stick.getRawButton(3)) {
				sol2.set(true);
				Timer.delay(.5);
				sol2.set(false);}
				
				
			
			if (logitech_stick.getRawButton(2)) {
				sol3.set(true);
				Timer.delay(.5);
				sol3.set(false);}
			
			
				sol3.set(false);
				sol2.set(false);
				sol1.set(false);
		 }
			
		
			
			
				/**Method called in "execute" method to operate the lift.**/
				public void lift() {
					if (logitech_stick.getRawButton(6)) {
						lift_motor.set(-.33);//right side
						
						
					}else if (logitech_stick.getRawButton(5)) {
						lift_motor.set(.33);//left side
						
					
					}else {
						lift_motor.set(-.06);//keep it staying still
						
					}
					
				}
				
				
			
		

		protected void initialize() {
			
		}

		protected void execute() {
			claw();
			lift();
		}

		protected boolean isFinished() {
			return false;
		}

		protected void end() {
			
		}

		protected void interrupted() {
			
		}

}
